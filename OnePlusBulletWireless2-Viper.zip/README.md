# OnePlusBulletWireless2-Viper
So I searched on google a lot, and found no settings for Bullet Wireless 2 on viper, so after combining couple of presets and kernels, ddc, here is a result I would like to share, it should improve your listening experience on BW2 a lot, stock Dirac is just so ****, so viper is the mandatory thing if you are a badass music listener

XDA: https://forum.xda-developers.com/oneplus-6t/themes/oneplus-bullet-wireless-2-profile-t4070917
